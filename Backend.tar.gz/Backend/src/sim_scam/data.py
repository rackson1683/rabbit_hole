import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta


def generate_sim_swap_data(user_type, num_records):
    data = []
    current_time = datetime.now()

    for _ in range(num_records):
        user_id = random.randint(1000, 9999)
        session_id = random.randint(10000, 99999)
        device_type = random.choice(['Mobile', 'Desktop', 'Tablet'])
        ip_address = f"192.168.{random.randint(0, 255)}.{random.randint(0, 255)}"
        location = random.choice(['Home', 'Office', 'Public Place', 'Unknown'])
        sim_change_request = random.choice([True, False])
        sim_activation_location = random.choice(['Local', 'International'])
        sim_swap_confirmation = random.choice([True, False])
        phone_number_change = random.choice([True, False])

        # Generate anomaly score and related attributes
        anomaly_score = 0
        anomaly_type = 'None'

        if sim_change_request and sim_swap_confirmation == False:
            anomaly_score += 0.4
            anomaly_type = 'SIM Swap Issue'

        if location == 'Unknown':
            anomaly_score += 0.2
            anomaly_type = 'Location Anomaly'

        if phone_number_change:
            anomaly_score += 0.3
            anomaly_type = 'Phone Number Change'

        if random.random() < 0.1:  # Adding random anomalies
            anomaly_score += 0.3

        anomaly_severity = min(1.0, anomaly_score)  # Clamped to a maximum of 1.0
        is_anomalous = 1 if anomaly_score > 0.5 else 0
        fraud_likelihood = np.random.uniform(0, 1) if is_anomalous else np.random.uniform(0, 0.4)

        data.append([
            user_id,
            session_id,
            current_time.strftime("%Y-%m-%d %H:%M:%S"),
            sim_change_request,
            sim_activation_location,
            sim_swap_confirmation,
            phone_number_change,
            location,
            ip_address,
            device_type,
            anomaly_score,
            is_anomalous,
            anomaly_type,
            anomaly_severity,
            fraud_likelihood
        ])

    columns = [
        'User ID', 'Session ID', 'Timestamp', 'SIM Change Request', 'SIM Activation Location',
        'SIM Swap Confirmation', 'Phone Number Change', 'Location', 'IP Address', 'Device Type',
        'Anomaly Score', 'Is Anomalous', 'Anomaly Type', 'Anomaly Severity', 'Fraud Likelihood'
    ]

    return pd.DataFrame(data, columns=columns)


# Generate datasets for all users
all_users_sim_swap = generate_sim_swap_data('All', 900)

# Randomly split users into 3 groups
user_groups_sim_swap = np.array_split(all_users_sim_swap, 3)

# Save each user group as a separate CSV file
for i, group in enumerate(user_groups_sim_swap, start=1):
    group.to_csv(f'data/sim_scam/user_group_{i}.csv', index=False)

print("CSV files generated successfully.")
