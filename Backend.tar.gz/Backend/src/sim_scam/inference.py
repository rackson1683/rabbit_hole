import torch
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import pickle

from src.models import SIMSwapScamDetectionModel

# ---------- Load and Preprocess Test Data ----------
def preprocess_input(df, scaler_path="models/sim_scam/scaler/scaler.pkl"):
    original_df = df.copy()

    # Drop non-feature columns
    features = df.drop(columns=[
        'User ID', 'Session ID', 'Timestamp', 'Location', 'IP Address',
        'Device Type', 'Anomaly Type', 'Is Anomalous', 
        'Anomaly Severity', 'Fraud Likelihood'
    ])

    # One-hot encode categorical columns
    features = pd.get_dummies(features, drop_first=True)

    # Load the saved scaler and apply normalization
    with open(scaler_path, "rb") as f:
        scaler = pickle.load(f)
    features_scaled = scaler.transform(features)

    return torch.tensor(features_scaled, dtype=torch.float32), original_df

# ---------- Load Model ----------
def load_model(model_path, input_size):
    model = SIMSwapScamDetectionModel(input_size)
    model.load_state_dict(torch.load(model_path))
    model.eval()
    return model

# ---------- Inference ----------
def run_inference(model, input_tensor):
    with torch.no_grad():
        is_anomalous, anomaly_severity, fraud_likelihood = model(input_tensor)
        is_anomalous = (is_anomalous >= 0.5).int().squeeze().numpy()
        anomaly_severity = anomaly_severity.squeeze().numpy()
        fraud_likelihood = fraud_likelihood.squeeze().numpy()
    return is_anomalous, anomaly_severity, fraud_likelihood

# ---------- Main Script ----------
if __name__ == "__main__":
    # Load test data
    test_data = pd.read_csv("data/sim_scam/user_group_1.csv")  # Replace with your actual test data path

    # Preprocess test data
    input_tensor, original_df = preprocess_input(test_data)

    # Load model
    input_size = input_tensor.shape[1]
    model = load_model("models/sim_scam/global/global.pth", input_size)

    # Run inference
    is_anomalous, anomaly_severity, fraud_likelihood = run_inference(model, input_tensor)

    # Append predictions to the original DataFrame
    original_df['Predicted_Is_Anomalous'] = is_anomalous
    original_df['Predicted_Anomaly_Severity'] = anomaly_severity
    original_df['Predicted_Fraud_Likelihood'] = fraud_likelihood

    # Save or display results
    original_df.to_csv("data/sim_scam/inference_output.csv", index=False)
    print(original_df[['User ID', 'Predicted_Is_Anomalous', 'Predicted_Anomaly_Severity', 'Predicted_Fraud_Likelihood']])
