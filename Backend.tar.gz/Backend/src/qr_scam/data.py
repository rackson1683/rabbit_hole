import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta


def generate_user_data(user_type, num_records):
    data = []
    current_time = datetime.now()

    for _ in range(num_records):
        user_id = random.randint(1000, 9999)
        session_id = random.randint(10000, 99999)
        typing_speed = np.random.normal(200, 50)  # Average typing speed in CPM
        typing_speed = max(50, typing_speed)

        qr_scan_duration = np.random.normal(5, 2)  # Average QR scan duration in seconds
        qr_scan_duration = max(0.5, qr_scan_duration)

        transaction_amount = np.random.uniform(100, 10000)
        transaction_frequency = np.random.randint(1, 10)
        location_change_frequency = np.random.uniform(0, 1)

        qr_details = random.choice(['Legit', 'Suspicious', 'Tampered', 'Legit'])

        # Enhanced QR Metadata
        encoding_type = random.choice(['UTF-8', 'ISO-8859-1', 'ASCII'])
        qr_version = random.randint(1, 10)
        error_correction_level = random.choice(['L', 'M', 'Q', 'H'])
        size = random.randint(21, 177)
        qr_density = random.uniform(0.5, 1.5)
        qr_content_length = random.randint(10, 300)
        qr_format = random.choice(['URL', 'Text', 'Payment', 'Contact Info', 'App Data'])

        ip_address = f"192.168.{random.randint(0, 255)}.{random.randint(0, 255)}"
        device_type = random.choice(['Mobile', 'Desktop', 'Tablet'])
        typing_pattern = random.choice(['Normal', 'Fast', 'Slow', 'Erratic'])
        location = random.choice(['Home', 'Office', 'Public Place', 'Unknown'])

        # Generate anomaly score and related attributes
        anomaly_score = 0
        anomaly_type = 'None'

        if typing_speed < 100 or typing_pattern == 'Erratic':
            anomaly_score += 0.3
            anomaly_type = 'Behavioral Anomaly'

        if qr_details in ['Suspicious', 'Tampered']:
            anomaly_score += 0.4
            anomaly_type = 'QR Metadata Issue'

        if location == 'Unknown':
            anomaly_score += 0.2
            anomaly_type = 'Transaction Anomaly'

        if random.random() < 0.1:  # Adding random anomalies
            anomaly_score += 0.3

        anomaly_severity = min(1.0, anomaly_score)  # Clamped to a maximum of 1.0
        is_anomalous = 1 if anomaly_score > 0.5 else 0
        fraud_likelihood = np.random.uniform(0, 1) if is_anomalous else np.random.uniform(0, 0.4)

        data.append([
            user_id,
            session_id,
            current_time.strftime("%Y-%m-%d %H:%M:%S"),
            typing_speed,
            qr_scan_duration,
            transaction_amount,
            transaction_frequency,
            location_change_frequency,
            qr_details,
            encoding_type,
            qr_version,
            error_correction_level,
            size,
            qr_density,
            qr_content_length,
            qr_format,
            ip_address,
            device_type,
            typing_pattern,
            location,
            anomaly_score,
            is_anomalous,
            anomaly_type,
            anomaly_severity,
            fraud_likelihood
        ])

    columns = [
        'User ID', 'Session ID', 'Timestamp', 'Typing Speed (CPM)', 'QR Scan Duration (s)',
        'Transaction Amount', 'Transaction Frequency', 'Location Change Frequency',
        'QR Details', 'Encoding Type', 'QR Version', 'Error Correction Level', 'Size',
        'QR Density', 'QR Content Length', 'QR Format', 'IP Address', 'Device Type',
        'Typing Pattern', 'Location', 'Anomaly Score', 'Is Anomalous',
        'Anomaly Type', 'Anomaly Severity', 'Fraud Likelihood'
    ]

    return pd.DataFrame(data, columns=columns)


# Generate datasets for all users
all_users = generate_user_data('All', 900)

# Randomly split users into 3 groups
user_groups = np.array_split(all_users, 3)

# Save each user group as a separate CSV file
for i, group in enumerate(user_groups, start=1):
    group.to_csv(f'data/qr_scam/user_group_{i}.csv', index=False)

print("CSV files generated successfully.")
