import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, recall_score, confusion_matrix
from torch.utils.data import DataLoader, TensorDataset
import copy
import os
import pickle

from src.models import QRScamDetectionModel

# Load the datasets
user_files = ["data/qr_scam/user_group_1.csv", "data/qr_scam/user_group_2.csv", "data/qr_scam/user_group_3.csv"]
user_data = [pd.read_csv(file) for file in user_files]

# Feature selection
def prepare_data(df, batch_size=32):
    features = df.drop(columns=['User ID', 'Session ID', 'Timestamp', 'QR Details', 'IP Address',
                                'Device Type', 'Location', 'Anomaly Type', 'Is Anomalous', 
                                'Anomaly Severity', 'Fraud Likelihood'])
    features = pd.get_dummies(features)
    labels = df[['Is Anomalous', 'Anomaly Severity', 'Fraud Likelihood']].values.astype(np.float32)
    
    scaler = StandardScaler()
    features = scaler.fit_transform(features)
    
    X = torch.tensor(features, dtype=torch.float32)
    y = torch.tensor(labels, dtype=torch.float32)
    
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
    
    train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(TensorDataset(X_val, y_val), batch_size=batch_size, shuffle=False)

    os.makedirs("models/qr_scam/scaler", exist_ok=True)
    with open("models/qr_scam/scaler/scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)
    
    return train_loader, val_loader, X_train.shape[1]

# Prepare datasets for each user
user_datasets = [prepare_data(df) for df in user_data]
input_size = user_datasets[0][2]

# Federated training parameters
epochs = 12
learning_rate = 0.001
batch_size = 32

def calculate_accuracy(y_pred, y_true):
    y_pred_labels = (y_pred >= 0.5).float()
    correct = (y_pred_labels == y_true).sum().item()
    return correct / len(y_true)

# Create directories for saving models if they don't exist
os.makedirs("models/qr_scam/client", exist_ok=True)
os.makedirs("models/qr_scam/global", exist_ok=True)

def train_federated(user_datasets, global_model, epochs, learning_rate):
    criterion = nn.MSELoss()
    client_models = [copy.deepcopy(global_model) for _ in user_datasets]

    for epoch in range(epochs):
        client_weights = []
        
        for client_idx, (train_loader, val_loader, _) in enumerate(user_datasets):
            model = client_models[client_idx]
            optimizer = optim.Adam(model.parameters(), lr=learning_rate)
            
            # Training Phase
            model.train()
            train_loss = 0.0
            train_accuracy = 0.0
            for X_batch, y_batch in train_loader:
                optimizer.zero_grad()
                is_anomalous_pred, anomaly_severity_pred, fraud_likelihood_pred = model(X_batch)
                
                loss_anomalous = criterion(is_anomalous_pred, y_batch[:, 0:1])
                loss_anomaly_severity = criterion(anomaly_severity_pred, y_batch[:, 1:2])
                loss_fraud_likelihood = criterion(fraud_likelihood_pred, y_batch[:, 2:3])
                
                total_loss = loss_anomalous + loss_anomaly_severity + loss_fraud_likelihood
                total_loss.backward()
                optimizer.step()
                
                train_loss += total_loss.item()
                train_accuracy += calculate_accuracy(is_anomalous_pred, y_batch[:, 0:1])
            
            train_loss /= len(train_loader)
            train_accuracy /= len(train_loader)
            
            # Validation Phase
            model.eval()
            val_loss = 0.0
            val_accuracy = 0.0
            with torch.no_grad():
                for X_val, y_val in val_loader:
                    is_anomalous_pred, anomaly_severity_pred, fraud_likelihood_pred = model(X_val)
                    
                    loss_anomalous = criterion(is_anomalous_pred, y_val[:, 0:1])
                    loss_anomaly_severity = criterion(anomaly_severity_pred, y_val[:, 1:2])
                    loss_fraud_likelihood = criterion(fraud_likelihood_pred, y_val[:, 2:3])
                    
                    total_loss = loss_anomalous + loss_anomaly_severity + loss_fraud_likelihood
                    val_loss += total_loss.item()
                    val_accuracy += calculate_accuracy(is_anomalous_pred, y_val[:, 0:1])
            
            val_loss /= len(val_loader)
            val_accuracy /= len(val_loader)
            client_weights.append(copy.deepcopy(model.state_dict()))
            
            print(f"Client {client_idx+1} - Epoch [{epoch+1}/{epochs}], Train Loss: {train_loss:.4f}, Train Acc: {train_accuracy:.4f}, Val Loss: {val_loss:.4f}, Val Acc: {val_accuracy:.4f}")
            
            # Save the client model
            torch.save(model.state_dict(), f"models/qr_scam/client/client_{client_idx+1}.pth")
        
        # Federated Averaging (FedAvg)
        global_weights = copy.deepcopy(client_weights[0])
        for key in global_weights.keys():
            for i in range(1, len(client_weights)):
                global_weights[key] += client_weights[i][key]
            global_weights[key] = global_weights[key] / len(client_weights)
        
        # Update global model
        global_model.load_state_dict(global_weights)
        print(f"--- Global Model Aggregated for Epoch [{epoch+1}/{epochs}] ---")

    # Save the global model
    torch.save(global_model.state_dict(), "models/qr_scam/global/global.pth")

    # === Final Evaluation of Global Model ===
    global_model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for _, val_loader, _ in user_datasets:
            for X_val, y_val in val_loader:
                is_anomalous_pred, _, _ = global_model(X_val)
                preds = (is_anomalous_pred >= 0.5).int().cpu().numpy().flatten()
                labels = y_val[:, 0].int().cpu().numpy().flatten()

                all_preds.extend(preds)
                all_labels.extend(labels)

    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)

    f1 = f1_score(all_labels, all_preds)
    r1 = recall_score(all_labels, all_preds)
    cm = confusion_matrix(all_labels, all_preds)

    print(f"\n=== Global Model Final Evaluation ===")
    print(f"F1 Score: {f1:.4f}")
    print(f"R1 Score (Recall): {r1:.4f}")
    print(f"Confusion Matrix:\n{cm}")

    return global_model

# Initialize the global model
global_model = QRScamDetectionModel(input_size)

# Train the model in a federated manner
global_model = train_federated(user_datasets, global_model, epochs, learning_rate)
