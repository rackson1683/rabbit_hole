import torch
import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import StandardScaler

from src.models import QRScamDetectionModel

# Load scaler
with open("models/qr_scam/scaler/scaler.pkl", "rb") as f:
    scaler: StandardScaler = pickle.load(f)

# Load global model
# Load a sample CSV to determine input size dynamically
sample_df = pd.read_csv("data/qr_scam/user_group_1.csv")
input_size = pd.get_dummies(
    sample_df.drop(columns=['User ID', 'Session ID', 'Timestamp', 'QR Details', 'IP Address',
                            'Device Type', 'Location', 'Anomaly Type', 'Is Anomalous', 
                            'Anomaly Severity', 'Fraud Likelihood'])
).shape[1]

model = QRScamDetectionModel(input_size)
model.load_state_dict(torch.load("models/qr_scam/global/global.pth"))
model.eval()

# Load new test data
test_df = pd.read_csv("data/qr_scam/user_group_1.csv")

# Save User ID & Session ID for reference in output
user_session_cols = test_df[['User ID', 'Session ID']]

# Drop unused columns
X = test_df.drop(columns=['User ID', 'Session ID', 'Timestamp', 'QR Details', 'IP Address',
                          'Device Type', 'Location', 'Anomaly Type', 'Is Anomalous', 
                          'Anomaly Severity', 'Fraud Likelihood'])

# One-hot encode and ensure all dummy columns match training set
X = pd.get_dummies(X)
X = X.reindex(columns=scaler.feature_names_in_, fill_value=0)

# Normalize
X_scaled = scaler.transform(X)
X_tensor = torch.tensor(X_scaled, dtype=torch.float32)

# Inference
with torch.no_grad():
    is_anomalous_pred, anomaly_severity_pred, fraud_likelihood_pred = model(X_tensor)

predictions = pd.DataFrame({
    "Is Anomalous Prediction": is_anomalous_pred.squeeze().numpy(),
    "Anomaly Severity Prediction": anomaly_severity_pred.squeeze().numpy(),
    "Fraud Likelihood Prediction": fraud_likelihood_pred.squeeze().numpy()
})

# Final output
output_df = pd.concat([user_session_cols.reset_index(drop=True), predictions], axis=1)
output_df.to_csv("data/qr_scam/predictions.csv", index=False)
print("✅ Predictions saved to data/qr_scam/predictions.csv")
