import torch
import torch.nn as nn


# Define the model
class QRScamDetectionModel(nn.Module):
    def __init__(self, input_size):
        super(QRScamDetectionModel, self).__init__()
        
        self.shared_layers = nn.Sequential(
            nn.Linear(input_size, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU()
        )
        
        self.output_is_anomalous = nn.Linear(64, 1)
        self.output_anomaly_severity = nn.Linear(64, 1)
        self.output_fraud_likelihood = nn.Linear(64, 1)
        
    def forward(self, x):
        shared_output = self.shared_layers(x)
        
        is_anomalous = torch.sigmoid(self.output_is_anomalous(shared_output))
        anomaly_severity = torch.sigmoid(self.output_anomaly_severity(shared_output))
        fraud_likelihood = torch.sigmoid(self.output_fraud_likelihood(shared_output))
        
        return is_anomalous, anomaly_severity, fraud_likelihood


# Define the model
class SIMSwapScamDetectionModel(nn.Module):
    def __init__(self, input_size):
        super(SIMSwapScamDetectionModel, self).__init__()
        
        self.shared_layers = nn.Sequential(
            nn.Linear(input_size, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU()
        )
        
        self.output_is_anomalous = nn.Linear(64, 1)
        self.output_anomaly_severity = nn.Linear(64, 1)
        self.output_fraud_likelihood = nn.Linear(64, 1)
        
    def forward(self, x):
        shared_output = self.shared_layers(x)
        
        is_anomalous = torch.sigmoid(self.output_is_anomalous(shared_output))
        anomaly_severity = torch.sigmoid(self.output_anomaly_severity(shared_output))
        fraud_likelihood = torch.sigmoid(self.output_fraud_likelihood(shared_output))
        
        return is_anomalous, anomaly_severity, fraud_likelihood
