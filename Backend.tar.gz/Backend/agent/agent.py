import re
import json

from phi.agent import Agent, RunResponse
from phi.model.openai import OpenAIChat

from agent.prompt import PROMPT, OUTPUT_FORMAT


def extract_json(text):
    match = re.search(r'```json\s*(\{.*?\})\s*```', text, re.DOTALL)
    if match:
        json_str = match.group(1)
        return json.loads(json_str)
    else:
        raise ValueError("No JSON block found.")

agent = Agent(
    model=OpenAIChat(id="gpt-4o",
                     base_url = "https://api.rabbithole.cred.club/v1",
                     api_key = "sk-Yc8yW-X7HmQW-646TEC3pg"),
    description="This is an AI Agent that takes in the inputs of risk scores and various other parameters to determine severity of transaction being scam between QR scam and SIM swap scam",
    instructions=[
        "Go through the paramters passed",
        "Paramters include risk scores for scam being SIM Swap or QR Scam and some other non sensetive data",
        "Predict the risk score for a transaction being scam or not"
        "Explore internet to understand each passed parameters",
        "Give output in this json  only: %s. only return json" % OUTPUT_FORMAT
    ],
    markdown=True,
    show_tool_calls=True,
    add_datetime_to_instructions=True,
    # debug_mode=True,
)

def get_response(fl_predictions, non_sensitive_params):
    response: RunResponse = agent.run(PROMPT % (fl_predictions, non_sensitive_params))
    agent.print_response(PROMPT % (fl_predictions, non_sensitive_params), stream=True)
    return extract_json(response.content)