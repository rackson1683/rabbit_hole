OUTPUT_FORMAT = "{'risk_score': , 'description': }"

PROMPT = "Based on given data points, Predict whether the transaction is SIM SCAM, QR " \
         "SCAM or good transaciton. In each case predict the risk score which you see." \
         "These are the parameters from trained FL models on local device: %s and these " \
         "are non sensitive paramters from local device: %s. Assume that predictions from FL models " \
         "can be faulty, so do your due diligence."