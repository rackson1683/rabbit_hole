import requests

url = "https://api.rabbithole.cred.club/v1/chat/completions"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer sk-Yc8yW-X7HmQW-646TEC3pg"
}
data = {
    "model": "gpt-4o",
    "messages": [
        {"role": "user", "content": "Hello world!"}
    ]
}

response = requests.post(url, headers=headers, json=data)
print(response.json())
