import random

from flask import Flask, jsonify
from flask_cors import CORS
from agent_response import AgentResponse

app = Flask(__name__)
CORS(app)
agent_response = AgentResponse()

count = 0

@app.route('/', methods=['GET'])
def index():
    return jsonify({
        "message": "Welcome to the Agent Response API.",
        "endpoints": {
            "QR Scam": "/qr_scam/<fraud|legit>",
            "SIM Scam": "/sim_scam/<fraud|legit>"
        }
    })


@app.route('/validate_transaction', methods=['GET'])
def validate_transaction():
    global count
    try:
        scam_type = random.choice(["sim", "qr"])
        fraud_legit = random.choice(["fraud", "legit"])

        # if scam_type == "sim":
        #     result = agent_response.get_sim_scam_agent_response(fraud_legit)
        # elif scam_type == "qr":
        #     result = agent_response.get_qr_scam_agent_response(fraud_legit)
        if count%2 == 0:
            result = agent_response.get_qr_scam_agent_response("fraud")
        if count%2 == 1:
            result = agent_response.get_qr_scam_agent_response("legit")
        count += 1
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
