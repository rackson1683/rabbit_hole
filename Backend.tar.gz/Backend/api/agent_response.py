import json
import random

from agent.agent import get_response


class AgentResponse:

    FRAUD = "fraud"
    LEGIT = "legit"
    FL_PREDICTION_ATTRS = ["Anomaly Type", "Anomaly Severity", "Fraud Likelihood"]

    def __init__(self,
                 qr_scam_pred_path="data/qr_scam/fl_predictions.json",
                 qr_scam_non_sensitive_path="data/qr_scam/non_sensitive.json",
                 sim_scam_pred_path="data/sim_scam/fl_predictions.json",
                 sim_scam_non_sensitive_path="data/sim_scam/non_sensitive.json"):
        self._qr_scam_fl_predictions = None
        self._sim_scam_fl_predictions = None
        self._qr_scam_non_sensitive_data = None
        self._sim_scam_non_sensitive_data = None

        with open(qr_scam_pred_path, 'r') as file:
            self._qr_scam_fl_predictions = json.load(file)
        
        with open(qr_scam_non_sensitive_path, 'r') as file:
            self._qr_scam_non_sensitive_data = json.load(file)

        with open(sim_scam_pred_path, 'r') as file:
            self._sim_scam_fl_predictions = json.load(file)
        
        with open(sim_scam_non_sensitive_path, 'r') as file:
            self._sim_scam_non_sensitive_data = json.load(file)


    def get_sim_scam_agent_response(self, type):
        
        non_sensitive_params = None
        fl_predictions = None

        if type == self.FRAUD:
            non_sensitive_params = random.choice(self._sim_scam_non_sensitive_data.get(self.FRAUD))
            fl_predictions = random.choice(self._sim_scam_fl_predictions.get(self.FRAUD))
        elif type == self.LEGIT:
            non_sensitive_params = random.choice(self._sim_scam_non_sensitive_data.get(self.LEGIT))
            fl_predictions = random.choice(self._sim_scam_fl_predictions.get(self.LEGIT))
        
        return get_response(fl_predictions, non_sensitive_params)

    def get_qr_scam_agent_response(self, type):

        non_sensitive_params = None
        fl_predictions = None

        if type == self.FRAUD:
            non_sensitive_params = random.choice(self._qr_scam_non_sensitive_data.get(self.FRAUD))
            fl_predictions = random.choice(self._qr_scam_fl_predictions.get(self.FRAUD))
            fl_predictions = {attr: fl_predictions[attr] for attr in self.FL_PREDICTION_ATTRS if attr in fl_predictions}
        elif type == self.LEGIT:
            non_sensitive_params = random.choice(self._qr_scam_non_sensitive_data.get(self.LEGIT))
            fl_predictions = random.choice(self._qr_scam_fl_predictions.get(self.LEGIT))
            fl_predictions = {attr: fl_predictions[attr] for attr in self.FL_PREDICTION_ATTRS if attr in fl_predictions}
        
        return get_response(fl_predictions, non_sensitive_params)

if __name__ == "__main__":
    agent_response = AgentResponse()
    agent_response.get_qr_scam_agent_response("fraud")
    agent_response.get_qr_scam_agent_response("legit")
    agent_response.get_sim_scam_agent_response("fraud")
    agent_response.get_sim_scam_agent_response("legit")
