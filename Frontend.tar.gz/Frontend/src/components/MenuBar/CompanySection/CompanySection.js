import React from "react";
import "./CompanySection.css";
import { MdCreditCard, MdPerson } from "react-icons/md";

const features = [
  { icon: MdCreditCard, label: "About Cred" },
  { icon: MdPerson, label: "Careers" },
];

function CompanySection() {
  return (
    <div className="payments-grid">
      {features.map(({ icon: IconComponent, label }) => (
        <div key={label} className="feature-box">
          <IconComponent className="feature-icon" />
          <span className="feature-label">{label.toUpperCase()}</span>
        </div>
      ))}
    </div>
  );
}

export default CompanySection;
