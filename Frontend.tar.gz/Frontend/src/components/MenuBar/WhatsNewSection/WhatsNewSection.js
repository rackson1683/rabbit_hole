import React from "react";
import "./WhatsNewSection.css";
import bannerImg from "../../../assets/banner.jpg"; // Replace with actual banner
import img1 from "../../../assets/img1.jpg";
import img2 from "../../../assets/img2.jpg";
import img3 from "../../../assets/img3.jpg";
import img4 from "../../../assets/img4.jpg";

const features = [
  {
    img: img1,
    title: "MONEY",
    desc: "track, analyze, and reflect on your financial behavior",
  },
  {
    img: img2,
    title: "GARAGE",
    desc: "manage, maintain, and obsess over your cars",
  },
  {
    img: img3,
    title: "PAY ANYONE",
    desc: "pay anyone, no matter what UPI app they’re on",
  },
  {
    img: img4,
    title: "WORK FOR CRED",
    desc: "apply to build the most trustworthy community",
  },
];

function WhatsNewSection() {
  return (
    <div className="whatsnew-container">
      <div className="banner-wrapper">
        <img src={bannerImg} alt="Banner" className="banner-image" />
        <div className="now-live-label">NOW LIVE</div>
      </div>
      <div className="features-grid">
        {features.map(({ img, title, desc }) => (
          <div className="feature-card" key={title}>
            <img src={img} alt={title} className="feature-image" />
            <div className="feature-title">{title}</div>
            <div className="feature-desc">{desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default WhatsNewSection;
