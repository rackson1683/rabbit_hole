// import React from "react";
// import "./PaymentsSection.css";
// import { MdContactless, MdCreditCard, MdPerson, MdQrCodeScanner } from "react-icons/md";


// // const features = [
// //   { icon: MdContactless, label: "Tap to Pay" },
// //   { icon: MdCreditCard, label: "Rupay Cards on UPI" },
// //   { icon: MdPerson, label: "Pay Anyone" },
// //   { icon: MdQrCodeScanner, label: "Scan & Pay" },
// // ];
// const features = [
//   { icon: MdContactless, label: "Tap to Pay", route: "/tap-to-pay" },
//   { icon: MdCreditCard, label: "Rupay Cards on UPI", route: "/rupay-upi" },
//   { icon: MdPerson, label: "Pay Anyone", route: "/pay-anyone" },
//   { icon: MdQrCodeScanner, label: "Scan & Pay", route: "/cred-pay" },
// ];


// function PaymentsSection() {
//   const handleScanAndPayClick = () => {
//     window.open("/cred-pay", "_blank"); // Opens the route in a new tab
//   };
//   return (
//     <div className="payments-grid">
//       {features.map(({ icon: IconComponent, label }) => (
//         <div key={label} className="feature-box">
//           <IconComponent className="feature-icon" />
//           <span className="feature-label">{label.toUpperCase()}</span>
//         </div>
//       ))}
//     </div>

//   );
// }

// export default PaymentsSection;
import React from "react";
import "./PaymentsSection.css";
import { Link } from "react-router-dom";
import {
  MdContactless,
  MdCreditCard,
  MdPerson,
  MdQrCodeScanner,
} from "react-icons/md";

const features = [
  { icon: MdContactless, label: "Tap to Pay", route: "/tap-to-pay" },
  { icon: MdCreditCard, label: "Rupay Cards on UPI", route: "/rupay-upi" },
  { icon: MdPerson, label: "Pay Anyone", route: "/pay-anyone" },
  { icon: MdQrCodeScanner, label: "Scan & Pay", route: "/cred-pay" },
];

function PaymentsSection() {
  return (
    <div className="payments-grid">
      {features.map(({ icon: IconComponent, label, route }) => (
        <Link to={route} key={label} className="feature-link">
          <div className="feature-box">
            <IconComponent className="feature-icon" />
            <span className="feature-label">{label.toUpperCase()}</span>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default PaymentsSection;
