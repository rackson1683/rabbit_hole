import React from "react";
import "./InsiderPerksSection.css";
import { MdQrCodeScanner } from "react-icons/md";

const features = [
  { icon: MdQrCodeScanner, label: "Upgare to UPI" },
];

function InsiderPerksSection() {
  return (
    <div className="payments-grid">
      {features.map(({ icon: IconComponent, label }) => (
        <div key={label} className="feature-box">
          <IconComponent className="feature-icon" />
          <span className="feature-label">{label.toUpperCase()}</span>
        </div>
      ))}
    </div>
  );
}

export default InsiderPerksSection;
