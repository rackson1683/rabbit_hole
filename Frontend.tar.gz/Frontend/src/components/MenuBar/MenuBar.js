import React, { useState } from "react";
import "./MenuBar.css";
import PaymentsSection from "./PaymentsSection/PaymentsSection";
import WhatsNewSection from "./WhatsNewSection/WhatsNewSection";
import UpgradesSection from "./UpgradesSection/UpgradesSection";
import CompanySection from "./CompanySection/CompanySection";
import InsiderPerksSection from "./InsiderPerksSection/InsiderPerksSection";

const menuItems = [
  { label: "WHAT'S NEW" },
  { label: "PAYMENTS" },
  { label: "UPGRADES" },
  { label: "COMPANY" },
  { label: "INSIDER PERKS" },
];

const contentData = {
  "WHAT'S NEW": <WhatsNewSection />,
  PAYMENTS: <PaymentsSection />,
  UPGRADES: <UpgradesSection />,
  COMPANY: <CompanySection />,
  "INSIDER PERKS": <InsiderPerksSection />,
};

const MenuBar = () => {
  const [hoveredIndex, setHoveredIndex] = useState(0); // ✅ default to "WHAT'S NEW"

  const handleMouseLeave = () => {
    setHoveredIndex(0); // ✅ Reset to default when mouse leaves the entire content area
  };

  return (
    <div className="split-menu-container" onMouseLeave={handleMouseLeave}>
      <div className="left-menu">
        {menuItems.map((item, index) => (
          <div
            key={index}
            className={`menu-item ${hoveredIndex === index ? "active" : ""}`}
            onMouseEnter={() => setHoveredIndex(index)}
          >
            {item.label}
          </div>
        ))}
      </div>

      <div className="right-content">
        {contentData[menuItems[hoveredIndex].label]}
      </div>
    </div>
  );
};

export default MenuBar;
