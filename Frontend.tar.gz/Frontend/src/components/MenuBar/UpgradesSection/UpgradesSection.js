import React from "react";
import "./UpgradesSection.css";
import { MdOutlineBeachAccess, MdDirectionsCar, MdPerson, MdAttachMoney } from "react-icons/md";

const features = [
  { icon: MdOutlineBeachAccess, label: "Travel" },
  { icon: MdDirectionsCar, label: "Garage" },
  { icon: MdPerson, label: "Mint" },
  { icon: MdAttachMoney, label: "Money" },
];

function UpgradesSection() {
  return (
    <div className="payments-grid">
      {features.map(({ icon: IconComponent, label }) => (
        <div key={label} className="feature-box">
          <IconComponent className="feature-icon" />
          <span className="feature-label">{label.toUpperCase()}</span>
        </div>
      ))}
    </div>
  );
}

export default UpgradesSection;
