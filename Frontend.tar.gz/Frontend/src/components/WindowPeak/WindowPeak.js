import React from 'react';
import "./WindowPeak.css";

const WindowPeak = () => {
  return (
    <div className='window-peak'></div>
  )
}

export default WindowPeak;