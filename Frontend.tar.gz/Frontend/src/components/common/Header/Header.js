import React, { useState } from "react";
import './Header.css';
import MenuBar from "../../MenuBar/MenuBar";

const Header = () => {
  const [showMobMenu, setShowMobMenu] = useState(false);
  const toggleMobileMenu = () => {
    setShowMobMenu(!showMobMenu);
  };

  const [showWebMenu, setShowWebMenu] = useState(false);
  const toggleWebMenu = () => {
    setShowWebMenu(!showWebMenu);
  };

  return (
    <div className="mobile-menu-wrapper">
      <div
        className={`mobile-menu only-mobile ${showMobMenu ? "overlay" : ":"}`}
      >
        <div className="mobile-navbar">
          <div className="mobile-nav-item">credit score check</div>
          <div className="mobile-nav-item">credit card bill payment</div>
        </div>
      </div>
      <div className="flex header">
        <img
          src="https://web-images.credcdn.in/_next/assets/images/home-page/cred-logo.png"
          className="header-logo"
          alt="header-logo"
        />
        <div className="only-mobile mobile-menu-button-wrapper">
          <button
            className={`hamburger hamburger--spin ${
              showMobMenu ? "is-active" : ""
            }`}
            type="button"
            onClick={toggleMobileMenu}
          >
            <span className="hamburger-box">
              <span className="hamburger-inner" />
            </span>
          </button>
        </div>
        <div className="non-mobile flex ">
          {/* <div className="header-nav-item">credit score check</div>
          <div className="header-nav-item">credit card bill payment</div> */}
          <button
            className={`hamburger hamburger--spin ${
              showWebMenu ? "is-active" : ""
            }`}
            type="button"
            onClick={toggleWebMenu}
          >
            <span className="hamburger-box">
              <span className="hamburger-inner" />
            </span>
          </button>
        </div>
      </div>
      {showWebMenu && (
  <div className="non-mobile">
    <div className="mobile-navbar">
      {/* <div className="mobile-nav-item">credit score check</div>
      <div className="mobile-nav-item">credit card bill payment</div> */}
      <MenuBar/>
    </div>
  </div>
)}
    </div>
  );
};

export default Header;
