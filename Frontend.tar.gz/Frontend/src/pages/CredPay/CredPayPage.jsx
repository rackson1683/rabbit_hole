import React, { useState } from "react";
import "./CredPayPage.css";
import { FaUpload } from "react-icons/fa";
import Header from "./Header/Header";
import axios from "axios";
import Modal from "react-modal";

// New Added
import spinner from '../../assets/spinner.gif';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {  FaSpinner, FaCheckCircle, FaExclamationTriangle , FaTimesCircle} from "react-icons/fa";
//------

Modal.setAppElement("#root");

const CredPayPage = () => {
  const [qrPreview, setQrPreview] = useState(null);
  const [amount, setAmount] = useState("");
  const [pin, setPin] = useState(["", "", "", "", "", ""]);
  const [upiId] = useState("example@upi");
  const [merchantName] = useState("PhonePe");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleQRUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setQrPreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handlePinChange = (value, index) => {
    const updatedPin = [...pin];
    updatedPin[index] = value;
    setPin(updatedPin);
  };

  const handlePayment = async () => {
    setIsProcessing(true);
    setModalContent(
      // New Added
      <div className="processing-indicator">
        <img src={spinner} className="spinner-icon" />
        <p>Processing your payment...</p>
      </div>

      //------
    );
    setIsModalOpen(true);

    try {
      await new Promise((resolve) => setTimeout(resolve, 3000));

      const response = await fetch("http://127.0.0.1:5000/validate_transaction");
      const data = await response.json();
      const { risk_score, description } = data;
      setIsProcessing(false);

      if (risk_score < 0.5) {
        setModalContent(
          <div className="modal-content">
            <div style={{ color: "green", fontWeight: "bold", fontSize: "1.5rem" }}>
              Payment seems safe!
            </div>
            <FaCheckCircle className="icon-success" size={50} />
            
            <p className="text-sm text-gray-700 mt-2">{description}</p>
          </div>
        );
        setTimeout(() => setIsModalOpen(false), 100000);
      } else if (risk_score >= 0.5 && risk_score <= 0.7) {
        setModalContent(
          <div className="modal-content">
            <div style={{ color: "orange", fontWeight: "bold", fontSize: "1.5rem" }}>
              Medium Risk Detected
            </div>
            <FaExclamationTriangle size={40} style={{ color: "orange" }} />
            <p>{description}</p>
            <div className="button-group">
              <button
                className="button-yes"
                onClick={proceedWithCaution}
              >
                Yes, Proceed
              </button>
              <button
                className="button-no"
                onClick={() => setIsModalOpen(false)}
              >
                No, Cancel
              </button>
            </div>
          </div>
        );
      } else {
        setModalContent(
          <div className="modal-content">
            <div style={{ color: "red", fontWeight: "bold", fontSize: "1.5rem" }}>
              High Risk Alert!
            </div>
            <FaTimesCircle size={40} style={{ color: "red" }} />
            
            <p className="text-sm text-gray-700 mt-2">{description}</p>
            <div className="button-group">
            <button
            className="button-yes"
            onClick={proceedWithCaution}
            >
              🔥 Yes, I'm Sure
            </button>

            <button
              className="button-no"
              onClick={() => setIsModalOpen(false)}
            >
              ❌ No, Take Me Back
            </button>
            </div>
          </div>
        );
      }
    } catch (error) {
      console.error(error);
      setIsProcessing(false);
      setModalContent(
        <div className="modal-content">
          <FaTimesCircle size={30} className="mr-3 text-red-600" />
          ❌ An error occurred during payment processing.
        </div>
      );
      setTimeout(() => setIsModalOpen(false), 3000);
    }
  };

  const proceedWithCaution = async () => {
    setIsProcessing(true);
    setModalContent(
      <div className="processing-indicator">
        <div className="spinner"></div>
        <p>Processing your payment...</p>
      </div>
    );

    try {
      await new Promise((resolve) => setTimeout(resolve, 3000));
      setIsProcessing(false);
      setModalContent(<p>✅ Payment completed successfully.</p>);
      setTimeout(() => setIsModalOpen(false), 10000);
    } catch (error) {
      setIsProcessing(false);
      setModalContent(<p>❌ An error occurred during payment processing.</p>);
      setTimeout(() => setIsModalOpen(false), 10000);
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    window.location.reload();
  };

  return (
    <>
      <Header />
      <div className="cred-pay-container">
        <div className="cred-left">
          <div className="cred-left-box">
            {!qrPreview ? (
              <div className="upload-box">
                <input
                  id="qr-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleQRUpload}
                  className="upload-input"
                />
                <label htmlFor="qr-upload" className="upload-label">
                  <FaUpload size={30} />
                  <span style={{ marginLeft: "10px" }}>UPLOAD QR CODE</span>
                </label>
              </div>
            ) : (
              <>
                <h1>Details</h1>
                <div className="qr-and-meta">
                  <div className="qr-preview">
                    <img src={qrPreview} alt="QR" />
                  </div>
                  <div className="upi-info">
                    <div className="upi-field">
                      <span className="upi-label">Merchant Name</span>
                    </div>
                    <div className="upi-field">
                      <span className="upi-value">{merchantName}</span>
                    </div>
                    <br />
                    <div className="upi-field">
                      <span className="upi-label">UPI ID</span>
                    </div>
                    <div className="upi-field">
                      <span className="upi-value">{upiId}</span>
                    </div>
                  </div>
                </div>

                <div className="amount-field">
                  <label className="cred-label">Amount</label>
                  <input
                    type="number"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="amount-input"
                  />
                </div>

                <div className="pin-field">
                  <label className="cred-label">6-digit PIN</label>
                  <div className="pin-container">
                    {pin.map((digit, idx) => (
                      <input
                        key={idx}
                        type="password"
                        maxLength="1"
                        className="pin-box"
                        value={digit}
                        onChange={(e) => handlePinChange(e.target.value, idx)}
                      />
                    ))}
                  </div>
                </div>

                <div className="button-wrapper">
                  <button className="cred-button" onClick={handlePayment}>
                    Pay Now
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="cred-right">
          <video autoPlay muted loop className="cred-video">
            <source
              src="https://web-images.credcdn.in/v2/_next/assets/videos/snp/snp_feature_01.mp4"
              type="video/mp4"
            />
          </video>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onRequestClose={() => setIsModalOpen(false)}
        className="ReactModal__Content"
        overlayClassName="ReactModal__Overlay"
        contentLabel="Payment Processing"
      >
        {modalContent}
        <button className="modal-close-button" onClick={handleCloseModal}>
          &times;
        </button>
      </Modal>
    </>
  );
};

export default CredPayPage;
