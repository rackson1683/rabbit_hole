import React from "react";
import { Link } from "react-router-dom"; // import Link
import './Header.css';

const Header = () => {
  return (
    <div className="scan-pay-header-wrapper">
      <div className="scan-pay-header-content">
        <Link to="/" className="logo-link">
          <img
            src="https://web-images.credcdn.in/_next/assets/images/home-page/cred-logo.png"
            className="scan-pay-header-logo"
            alt="scan-pay-header-logo"
          />
        </Link>
        <h1 className="scan-pay-header-title">Scan any QR securely</h1>
      </div>
    </div>
  );
};

export default Header;
